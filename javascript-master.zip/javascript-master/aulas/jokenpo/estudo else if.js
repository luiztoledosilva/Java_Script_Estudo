if (condição){
	//condição verdadeira
}

if (condição){
	//condição verdadeira
} else{
	//condição falsa
}

if (condição 1){
	//condição 1 verdadeira
} else if (condição 2){
	//condição 2 verdadeira
} else if (condição 3){
	//condição 3 verdadeira
} else {
	//caso nenhuma condição seja verdadeira
}
	