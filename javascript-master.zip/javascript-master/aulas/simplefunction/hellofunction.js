/**
* JS - Aula4: Função simples
* @author Professor José de Assis
*/

function hello(){
	var nome;
	nome = prompt("Qual é o seu nome?");
	alert("Hello " + nome);
}