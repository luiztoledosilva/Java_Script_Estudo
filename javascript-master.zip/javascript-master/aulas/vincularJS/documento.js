/**
* JS - Aula3: Vinculando um documento JS
* @author Professor José de Assis
*/

document.write("<h2>" + "Professor José de Assis" + "</h2>");