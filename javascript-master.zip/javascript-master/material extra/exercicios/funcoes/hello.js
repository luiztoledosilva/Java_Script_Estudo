/**
 * Exemplo de uma função simples
 * @author José de Assis
 */

 function helloWorld(){
     let nome
     nome = promp ('Qual é o seu nome ?')
     alert ('Hello ' + nome)
 }