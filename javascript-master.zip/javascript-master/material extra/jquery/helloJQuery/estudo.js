/**
 * Estudo da biblioteca JQuery
 * @author José de Assis
 */

 $('#efeito').fadeOut(5000).fadeIn(5000)